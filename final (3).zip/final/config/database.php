<?php
class Database {

    protected $dbHostname = 'localhost';
    protected $dbUsername = 'root';
    protected $dbPassword = '';
    protected $dbDatabase = 'db_klinik';

    public function connect() {

        return mysqli_connect(
            $this->dbHostname,
            $this->dbUsername,
            $this->dbPassword,
            $this->dbDatabase
        );
    }
}