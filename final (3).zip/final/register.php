<?php

// Untuk memulai session
session_start();

require "config/database.php";

class Register extends Database {
    
    protected $dbConnection;
    protected $name;
    protected $username;
    protected $password;
    protected $birth_date;

    public function __construct($name, $username, $password, $birth_date) {
        $this->name = $name;
        $this->username = $username;
        $this->password = $password;
        $this->birth_date = $birth_date;

        $this->dbConnection = $this->connect();
    }

    public function register() {
        return mysqli_query(
            $this->dbConnection,
            "INSERT INTO `tbl_user`
            (`username_tu`, `password_tu`, `nama_tu`, `tanggal_lahir_tu`)
            VALUES 
            ('{$this->username}', '{$this->password}', '{$this->name}', '{$this->birth_date}')"
        );
    }

}


// Cek apakah semua data sudah diisi
if(isset($_POST["name"], $_POST["username"], $_POST["password"], $_POST["birth_date"])) {

    // Encode $_POST['password'] ke md5
    $_POST['password'] = md5($_POST['password']);

    $register = new Register(
        $_POST['name'],
        $_POST['username'],
        $_POST['password'],
        $_POST['birth_date']
    );

    // Query untuk insert data ke database
    $query = $register->register();

    // Cek apakah insert data berhasil
    if($query >= 1) {

        $_SESSION["register_status"] = true;
        header("location: index.php");
    } else {
        $_SESSION["register_status"] = false;
        header("location: tambah_akun.php");
    }
}
?>