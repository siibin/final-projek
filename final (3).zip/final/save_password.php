<?php

/**
 * Tahapan update password
 * 1. Cek apakah new_password sama dengan renew_password.
 *    Kalau tidak kasih keterngan kalau renew_password tidak sama
 * 2. Cek apakah password inputan ($_POST['password']) sama dengan password di database yang sudah di MD5. 
 *    Kalau tidak kasih keterangan password inputan tidak sama
 * 3. Update password dengan password yang baru mengambil dari new_password.
 *    Kalau update berhasil kasih keterangan update berhasil.
 *    Kalau tidak kasih keterangan update gagal
 */

// Mulai session
session_start();

// Koneksi database
$database = mysqli_connect("localhost","root","","db_klinik");

if(isset($_SESSION['renew_password_status'])) unset($_SESSION['renew_password_status']);
if(isset($_SESSION['current_password_status'])) unset($_SESSION['current_password_status']);
if(isset($_SESSION['save_password_status'])) unset($_SESSION['save_password_status']);

if(isset($_POST['id'], $_POST['password'], $_POST['new_password'], $_POST['renew_password'])) {

    // Cek apakah password baru dengan password renew nilainya sama
    if($_POST['new_password'] == $_POST['renew_password']) {

        // Kalau nilainya sama
        $query = mysqli_query(
            $database, 
            "SELECT `password_tu` FROM `tbl_user` WHERE `id_tu` = '$_POST[id]'"
        );

        $data = mysqli_fetch_array($query);

        $_POST['password'] = md5($_POST['password']);

        // Cek apakah $_POST['password'] sama dengan password di database
        if($_POST['password'] == $data['password_tu']) {

            $_POST['new_password'] = md5($_POST['new_password']);

            // Kalau nilainya sama
            $query = mysqli_query(
                $database,
                "UPDATE tbl_user
                SET 
                `password_tu`='$_POST[new_password]'
                
                WHERE id_tu = '$_POST[id]'"
            );

            if($query == true) {

                // Kalau update password berhasil
                $_SESSION['save_password_status'] = true;
                header("Location: profile.php");
            } else {

                // Kalau update password gagal
                $_SESSION['save_password_status'] = false;
                header("Location: profile.php");
            }
        } else {

            // Kalau nilainya tidak sama
            $_SESSION['current_password_status'] = false;
            header("Location: profile.php");
        }
    } else {

        // Kalau nilainya tidak sama
        $_SESSION['renew_password_status'] = false;
        header("Location: profile.php");
    }
} else {

    echo "No data";
}
?>