<?php

session_start();

require "config/database.php";

class Login extends Database {
   
   protected $username;
   protected $password;
   protected $dbConnection;

   public function __construct($username, $password) {
      $this->username = $username;
      $this->password = $password;

      $this->dbConnection = $this->connect();
   }
   public function login() {
      return mysqli_query(
         $this->dbConnection,
            "SELECT * 
            FROM `tbl_user` 
            WHERE username_tu = '{$this->username}' 
            and password_tu = '{$this->password}'"
         );
   }
}

if(isset($_POST['username'], $_POST['password'])) {
   $_POST['password'] = md5($_POST['password']);

   $login = new Login($_POST['username'], $_POST['password']);
   $query = $login->login();

   $data = mysqli_fetch_array($query);

    if(is_array($data) && count($data) >= 1) {

        $_SESSION['username'] = $_POST['username'];
        // include "admin.php";
        header('location: admin.php');
     } else {
        $_SESSION['login-status'] = false;
        header('location: index.php');
     }
} else {

    echo "Kosong";
}