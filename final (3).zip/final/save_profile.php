<?php

// Mulai session
session_start();

require "config/database.php";

class SaveProfile extends Database {
    protected $dbConnection;
    protected $id;
    protected $fullname;
    protected $alamat;
    protected $tanggal_lahir;
    protected $jenis_kelamin;

    public function __construct($id, $fullname, $alamat, $tanggal_lahir, $jenis_kelamin) {
        $this->id = $id;
        $this->fullname = $fullname;
        $this->alamat = $alamat;
        $this->tanggal_lahir = $tanggal_lahir;
        $this->jenis_kelamin = $jenis_kelamin;

        $this->dbConnection = $this->connect();
    }

    public function save() {
        return mysqli_query(
            $this->dbConnection,
            "UPDATE tbl_user
            SET 
            `nama_tu`='{$this->fullname}',
            `alamat_tu`='{$this->alamat}',
            `tanggal_lahir_tu`='{$this->tanggal_lahir}',
            `jenis_kelamin_tu`='{$this->jenis_kelamin}'
            
            WHERE id_tu = '{$this->id}'"
        );
    
    }
} 

if(isset($_POST['id'], $_POST['fullname'], $_POST['alamat'], $_POST['tanggal_lahir'], $_POST['jenis_kelamin'])) {

    $save_profile = new SaveProfile(
        $_POST['id'],
        $_POST['fullname'],
        $_POST['alamat'],
        $_POST['tanggal_lahir'],
        $_POST['jenis_kelamin']
    );

    // Query untuk insert data ke database
    $query = $save_profile->save();

    if($query == true) {

        // Kalau update data berhasil
        $_SESSION['save_profile_status'] = true;
        header("Location: profile.php");
    } else {

        // Kalau update data gagal
        $_SESSION['save_profile_status'] = false;
        header("Location: profile.php");
    }
} else {

    echo "No data";
}
?>