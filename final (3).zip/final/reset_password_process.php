<?php

// Untuk memulai session
session_start();

// Koneksi database
$database = mysqli_connect("localhost","root","","db_klinik");

// Cek apakah semua data sudah diisi
if(isset($_POST["username"], $_POST["password"])) {

    // Encode $_POST['password'] ke md5
    $_POST['password'] = md5($_POST['password']);

    $query = mysqli_query(
        $database, 
        "
            UPDATE `tbl_user`
            SET
                `password_tu`='$_POST[password]'
            WHERE 
                `username_tu` = '$_POST[username]'
        ");

    if($query) {

        // Kalau berhasil
        header('Location: index.php');
    } else {

        // Kalau gagal
        $_SESSION['reset_pass_status'] = false;
        header('Location: reset_password.php');
    }
} else {

    // Code...
}
